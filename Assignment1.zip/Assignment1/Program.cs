﻿namespace SmashBrosThing
{
    class Program
    {
        private static List<Character> characters = new List<Character>();

        static void Main()
        {
            while (true)
            {
                Console.WriteLine("1. Add Character\n2. Display Characters\n3. Exit");
                switch (Console.ReadLine())
                {
                    case "1":
                        AddCharacter();
                        break;
                    case "2":
                        DisplayCharacters();
                        break;
                    case "3":
                        return;
                    default:
                        Console.WriteLine("Invalid choice. Please try again.");
                        break;
                }
            }
        }

        static void AddCharacter()
        {
            Console.Write("Enter Id: ");
            string id = Console.ReadLine();

            Console.Write("Enter Name: ");
            string name = Console.ReadLine();

            Console.Write("Enter Relationship to Mario: ");
            string relationship = Console.ReadLine();

            characters.Add(new Character { Id = id, Name = name, Relationship = relationship });
            Console.WriteLine("Character added!");
        }

        static void DisplayCharacters()
        {
            if (characters.Count > 0)
                characters.ForEach(character => Console.WriteLine($"Id: {character.Id}\nName: {character.Name}\nRelationship: {character.Relationship}\n"));
        }
    }

    class Character
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Relationship { get; set; }
    }
}